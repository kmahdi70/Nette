<?php
return array (
  0 => 
  array (
    'App\\Model\\ArticleManager' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project_me\\app\\model\\ArticleManager.php',
      'time' => 1506343839,
    ),
    'App\\Model\\User' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project_me\\app\\model\\User.php',
      'time' => 1507126579,
    ),
    'App\\Presenters\\Error4xxPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project_me\\app\\presenters\\Error4xxPresenter.php',
      'time' => 1506169329,
    ),
    'App\\Presenters\\ErrorPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project_me\\app\\presenters\\ErrorPresenter.php',
      'time' => 1506169329,
    ),
    'App\\Presenters\\HomePresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project_me\\app\\presenters\\HomePresenter.php',
      'time' => 1506932226,
    ),
    'App\\Presenters\\LoginPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project_me\\app\\presenters\\LoginPresenter.php',
      'time' => 1507104370,
    ),
    'App\\Presenters\\UserPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project_me\\app\\presenters\\UserPresenter.php',
      'time' => 1507126479,
    ),
    'App\\RouterFactory' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project_me\\app\\router\\RouterFactory.php',
      'time' => 1506411948,
    ),
  ),
  1 => 
  array (
    'Nette\\Environment' => 3,
  ),
);
