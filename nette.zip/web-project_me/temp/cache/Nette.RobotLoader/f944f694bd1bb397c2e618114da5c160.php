<?php
return array (
  0 => 
  array (
    'App\\Model\\ArticleManager' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project\\app\\model\\ArticleManager.php',
      'time' => 1506343839,
    ),
    'App\\Presenters\\Error4xxPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project\\app\\presenters\\Error4xxPresenter.php',
      'time' => 1506169329,
    ),
    'App\\Presenters\\ErrorPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project\\app\\presenters\\ErrorPresenter.php',
      'time' => 1506169329,
    ),
    'App\\Presenters\\HomePresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project\\app\\presenters\\HomePresenter.php',
      'time' => 1506932226,
    ),
    'App\\Presenters\\LoginPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project\\app\\presenters\\LoginPresenter.php',
      'time' => 1507104370,
    ),
    'App\\RouterFactory' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project\\app\\router\\RouterFactory.php',
      'time' => 1506411948,
    ),
    'App\\Presenters\\UserPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project\\app\\presenters\\UserPresenter.php',
      'time' => 1507126479,
    ),
    'App\\Model\\User' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\web-project\\app\\model\\User.php',
      'time' => 1507126579,
    ),
  ),
  1 => 
  array (
    'Nette\\Environment' => 41,
    'App\\Presenters\\Post1Presenter' => 1,
    'App\\Presenters\\HomepagePresenter' => 3,
    'App\\Presenters\\LogPresenter' => 1,
    'App\\Presenters\\LPresenter' => 1,
    'App\\Presenters\\ArticleManager' => 2,
    'App\\Presenters\\APresenter' => 3,
    'App\\Presenters\\SdsdsPresenter' => 3,
    'App\\Presenters\\Message' => 1,
    'App\\Presenters\\MessagePresenter' => 1,
    'App\\Presenters\\Form' => 3,
    'App\\Model\\DateTime' => 1,
    'App\\Presenters\\PostPresenter' => 1,
    'App\\Presenters\\PresenterPresenter' => 1,
    'App\\Presenters\\PresentersPresenter' => 1,
  ),
);
