<?php
// source: C:\xampp\htdocs\web-project\app\presenters\templates\en_error.latte

use Latte\Runtime as LR;

class Template87a8d7583a extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
{
define("ErrNum_100","ورودی نا معتبر است");
define("ErrNum_101","No Database");
define("ErrNum_102","نام کاربری یا رمز عبور اشتباه است");
define("ErrNum_103","با موفقیت وارد شدید");
define("ErrNum_104","Restricted Access to this page");
define("ErrNum_105","Table does not exist");
define("ErrNum_106","No Database Connection");
define("ErrNum_107","No Database found");
define("ErrNum_108","خطا در اجرای پرس و جو");
define("ErrNum_118","با موفقیت خارج شدید");
define("ErrNum_121","بازی با موفقیت افزوده گردید");
define("ErrNum_122","خطا در آپلود فایل");
define("ErrNum_123","تورنمنت با موفقیت افزوده گردید");
define("ErrNum_124","نشان با موفقیت افزوده گردید");
define("ErrNum_125","تکنولوژی با موفقیت افزوده گردید");
define("ErrNum_126","دسته با موفقیت افزوده گردید");
define("ErrNum_127","کاربر با موفقیت ایجاد گردید");
define("ErrNum_128","بازی با موفقیت بروزرسانی گردید");
define("ErrNum_129","تورنمنت با موفقیت بروزرسانی گردید");
define("ErrNum_130","کاربر با موفقیت بروزرسانی گردید");
define("ErrNum_131","نشان با موفقیت بروزرسانی گردید");
define("ErrNum_132","تکنولوژی با موفقیت بروزرسانی گردید");
define("ErrNum_133","دسته با موفقیت بروزرسانی گردید");
define("ErrNum_134","لیدربرد با موفقیت بروزرسانی گردید");
define("ErrNum_135","پلی لیست با موفقیت بروزرسانی گردید");

function Show_Msg($Str){
if($Str != '') {
if (defined("ErrNum_" . $Str))
eval("print(ErrNum_" . htmlentities($Str) . ");");
else
print("خطای شماره " . htmlentities($Str));
}
}

$Str = '';
$Col = '0';

if($Msg != '0') {
$msg_arr = explode('_', $Msg);
$Col = strtolower($msg_arr[0]);
$Str = $msg_arr[1];
}
$ShowDiv = array('0' => array('g' => 'none','r' => 'none','y' => 'none'),
'g' => array('g' => 'block','r' => 'none','y' => 'none'),
'r' => array('g' => 'none','r' => 'block','y' => 'none'),
'y' => array('g' => 'none','r' => 'none','y' => 'block'));
}
<div class="container" id="System_Message" style="margin-top: 10px">
    <div class="alert alert-success alert-dismissable" id="MsgDiv_G" style="display:{ echo $ShowDiv[$Col]['g'];};">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        <strong>Success!</strong> <span id="Msg_G">{ Show_Msg($Str);}</span>
    </div>
    <div class="alert alert-danger alert-dismissable" id="MsgDiv_R" style="display:{ echo $ShowDiv[$Col]['r'];};">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        <strong>Failed!</strong> <span id="Msg_R">{ Show_Msg($Str);}</span>
    </div>
    <div class="alert alert-warning alert-dismissable" id="MsgDiv_Y" style="display:{ echo $ShowDiv[$Col]['y'];};">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        <strong>Warning!</strong> <span id="Msg_Y">{ Show_Msg($Str);}</span>
    </div>
</div>
<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}

}
