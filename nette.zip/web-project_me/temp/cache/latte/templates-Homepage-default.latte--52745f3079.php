<?php
// source: C:\xampp\htdocs\web-project\app\presenters/templates/Homepage/default.latte

use Latte\Runtime as LR;

class Template52745f3079 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
		'Title' => 'blockTitle',
	];

	public $blockTypes = [
		'content' => 'html',
		'Title' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['post'])) trigger_error('Variable $post overwritten in foreach on line 6');
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	function blockContent($_args)
	{
		extract($_args);
		$this->renderBlock('Title', get_defined_vars());
?>
<hr>
    <!--<a n:href="Post:create">Write new post</a>-->
<?php
		if ($user->loggedIn) {
			?>    <a href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Post:create")) ?>">Create post</a>
<?php
		}
		$iterations = 0;
		foreach ($posts as $post) {
?>
        <div class="post">
            <h2><a href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Post:show", [$post->id])) ?>"><?php
			echo LR\Filters::escapeHtmlText($post->title) /* line 8 */ ?></a></h2>
            <div class="date"><?php echo LR\Filters::escapeHtmlText(call_user_func($this->filters->date, $post->created_at, 'Y-m-d h:i:s')) /* line 9 */ ?></div>

            <h2>ID= <?php echo LR\Filters::escapeHtmlText($post->id) /* line 11 */ ?>) <?php echo LR\Filters::escapeHtmlText($post->title) /* line 11 */ ?></h2>

            <div><?php echo LR\Filters::escapeHtmlText($post->content) /* line 13 */ ?></div>
        </div>
        <hr>
<?php
			$iterations++;
		}
?>

<?php
	}


	function blockTitle($_args)
	{
		extract($_args);
?><h1>Page Title</h1>
<?php
	}

}
