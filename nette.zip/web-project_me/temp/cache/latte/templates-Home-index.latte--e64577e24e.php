<?php
// source: C:\xampp\htdocs\web-project_me\app\presenters/templates/Home/index.latte

use Latte\Runtime as LR;

class Templatee64577e24e extends Latte\Runtime\Template
{
	public $blocks = [
		'header' => 'blockHeader',
		'content' => 'blockContent',
		'footer' => 'blockFooter',
	];

	public $blockTypes = [
		'header' => 'html',
		'content' => 'html',
		'footer' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('header', get_defined_vars());
?>

<?php
		$this->renderBlock('content', get_defined_vars());
?>

<?php
		$this->renderBlock('footer', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	function blockHeader($_args)
	{
		
	}


	function blockContent($_args)
	{
		extract($_args);
		/* line 5 */
		$this->createTemplate('../menu.latte', $this->params, "include")->renderToContentType('html');
		/* line 6 */
		$this->createTemplate('../message.latte', $this->params, "include")->renderToContentType('html');
?>
<div class="container">
    <div class="row" id="NewGame">
        <div class="col col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading" id="Panel_Title">
                    <i class="fa fa-folder-open-o" aria-hidden="true" id="Panel_Icon"></i>
                    <label class="control-label">Sample</label>
                </div>
                <div class="panel-body" id="Panel_Body">
                    <div class="col col-md-12">
                        Natte Framework
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
	}


	function blockFooter($_args)
	{
		extract($_args);
?>
    <script>
    $(document).ready( function() {
        $('[id^=MsgDiv_]').fadeOut(5000);
    });
    </script>
<?php
	}

}
