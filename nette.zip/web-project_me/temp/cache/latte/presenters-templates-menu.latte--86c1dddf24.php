<?php
// source: C:\xampp\htdocs\web-project_me\app\presenters\templates\menu.latte

use Latte\Runtime as LR;

class Template86c1dddf24 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<div class="container" style="margin-top: 10px">
    <nav class="navbar navbar-default" style="border-radius: 5px;">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Vira</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav">
                    <li <?php
		if ($this->global->uiPresenter->isLinkCurrent("Home:index")) {
			?>class="active"<?php
		}
		?>><a href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Home:index")) ?>">Home</a></li>
                    <li class="dropdown <?php
		if ($this->global->uiPresenter->isLinkCurrent("User:*")) {
			?>active<?php
		}
?>">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">User <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("User:add")) ?>">Add User</a></li>
                            <li><a href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("User:view")) ?>">View Users</a></li>
                            <li><a href="#">Edit Users</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Login:logoff")) ?>">Log Off</a></li>
                        </ul>
                    </li>

                </ul>
                <form class="navbar-form navbar-left">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search">
                        <div class="input-group-btn">
                            <button class="btn btn-default" type="submit">
                                <i class="fa fa-search" aria-hidden="true" style="font-size: 20px"></i>
                            </button>
                        </div>
                    </div>
                </form>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Login:logoff")) ?>"><i class="fa fa-sign-out" aria-hidden="true"></i> Log off</a></li>
                </ul>
            </div>
        </div>
    </nav>
</div>
<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}

}
