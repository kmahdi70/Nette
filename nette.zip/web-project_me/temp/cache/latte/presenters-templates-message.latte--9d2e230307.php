<?php
// source: C:\xampp\htdocs\web-project\app\presenters\templates\message.latte

use Latte\Runtime as LR;

class Template9d2e230307 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<div class="container" id="System_Message">
    <div class="alert alert-success alert-dismissable" id="MsgDiv_G" style="display: <?php echo LR\Filters::escapeHtmlAttr(LR\Filters::escapeCss($ShowDiv[$Col]['g'])) /* line 2 */ ?>">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        <strong>Success!</strong> <span id="Msg_G"><?php echo LR\Filters::escapeHtmlText($Msg) /* line 4 */ ?></span>
    </div>
    <div class="alert alert-danger alert-dismissable" id="MsgDiv_R" style="display:<?php echo LR\Filters::escapeHtmlAttr(LR\Filters::escapeCss($ShowDiv[$Col]['r'])) /* line 6 */ ?>">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        <strong>Failed!</strong> <span id="Msg_R"><?php echo LR\Filters::escapeHtmlText($Msg) /* line 8 */ ?></span>
    </div>
    <div class="alert alert-warning alert-dismissable" id="MsgDiv_Y" style="display:<?php echo LR\Filters::escapeHtmlAttr(LR\Filters::escapeCss($ShowDiv[$Col]['y'])) /* line 10 */ ?>;">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        <strong>Warning!</strong> <span id="Msg_Y"><?php echo LR\Filters::escapeHtmlText($Msg) /* line 12 */ ?></span>
    </div>
</div>
<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}

}
