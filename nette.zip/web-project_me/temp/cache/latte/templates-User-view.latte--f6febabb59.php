<?php
// source: C:\xampp\htdocs\web-project\app\presenters/templates/User/view.latte

use Latte\Runtime as LR;

class Templatef6febabb59 extends Latte\Runtime\Template
{
	public $blocks = [
		'header' => 'blockHeader',
		'content' => 'blockContent',
		'footer' => 'blockFooter',
	];

	public $blockTypes = [
		'header' => 'html',
		'content' => 'html',
		'footer' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('header', get_defined_vars());
?>

<?php
		$this->renderBlock('content', get_defined_vars());
?>

<?php
		$this->renderBlock('footer', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	function blockHeader($_args)
	{
?><link rel="stylesheet" href="../css/jquery.dataTables.min.css">
<?php
	}


	function blockContent($_args)
	{
		extract($_args);
		/* line 6 */
		$this->createTemplate('../menu.latte', $this->params, "include")->renderToContentType('html');
		/* line 7 */
		$this->createTemplate('../message.latte', $this->params, "include")->renderToContentType('html');
?>

<div class="container">
    <div class="row" id="ViewUser">
        <style scoped type="text/css">
            input[type=search]{
                border: 1px solid #b2b2b2;
            }
        </style>
        <div class="col col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">View Users</div>
                <div class="panel-body">
                    <div class="col col-md-12">
                        <div class="table-responsive">
                            <table id="ViewUserTB" class="display" width="100%" cellspacing="0">
                                <thead>
                                <tr>
                                    <th>UID</th>
                                    <th>FName</th>
                                    <th>LName</th>
                                    <th>Photo</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th>UID</th>
                                    <th>FName</th>
                                    <th>LName</th>
                                    <th>Photo</th>
                                    <th>Action</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="ConfirmDell" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Confirm Delete</h4>
            </div>
            <div class="modal-body ">
                <p>Are you sure you want to delete?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger btn-ok" onclick="DeleteUser();">Delete</a>
            </div>
        </div>
    </div>
</div>
<input type="hidden" id="DellID">
<?php
	}


	function blockFooter($_args)
	{
		extract($_args);
?>
<script src="../js/jquery.dataTables.min.js" type="text/javascript"></script>
<script>
    var link = <?php echo LR\Filters::escapeJs($this->global->uiControl->link("User:feedUser")) ?>


    $('#ViewUserTB').DataTable( {
        "ajax":link,
        "drawCallback": function() {
            $('[data-toggle="tooltip"]').tooltip();
        }
    });
    var Cell;
    function ConfirmDelete(uid,obj){
        $('#DellID').val(uid);
        Cell = obj;
    }

    function DeleteUser() {
        $('#ConfirmDell').modal('hide');
        var URL = <?php echo LR\Filters::escapeJs($this->global->uiControl->link("User:delete")) ?>;
        var uid = $('#DellID').val();
        $.post(URL, { UID:uid }, function (res, ret) {
            if (ret == 'success') {
                if (res == '1') {
                    window.location = <?php echo LR\Filters::escapeJs($this->global->uiControl->link("User:view?Msg=G_112")) ?>;
                }
            }
        });
    }

    $(document).ready( function() {
        $('[id^=MsgDiv_]').fadeOut(5000);
    });
    </script>
<?php
	}

}
