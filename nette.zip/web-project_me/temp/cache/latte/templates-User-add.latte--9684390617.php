<?php
// source: C:\xampp\htdocs\web-project_me\app\presenters/templates/User/add.latte

use Latte\Runtime as LR;

class Template9684390617 extends Latte\Runtime\Template
{
	public $blocks = [
		'header' => 'blockHeader',
		'content' => 'blockContent',
		'footer' => 'blockFooter',
	];

	public $blockTypes = [
		'header' => 'html',
		'content' => 'html',
		'footer' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('header', get_defined_vars());
?>

<?php
		$this->renderBlock('content', get_defined_vars());
?>

<?php
		$this->renderBlock('footer', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	function blockHeader($_args)
	{
		
	}


	function blockContent($_args)
	{
		extract($_args);
		/* line 5 */
		$this->createTemplate('../menu.latte', $this->params, "include")->renderToContentType('html');
		/* line 6 */
		$this->createTemplate('../message.latte', $this->params, "include")->renderToContentType('html');
?>

<div class="container">
    <div class="row" id="NewUser">
        <div class="col col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading" id="Panel_Title">
                    <i class="fa fa-folder-open-o" aria-hidden="true" id="Panel_Icon"></i>
                    <label class="control-label">Add New User</label>
                </div>
                <div class="panel-body" id="Panel_Body">
                    <div class="col col-md-12">
<?php
		$form = $_form = $this->global->formsStack[] = $this->global->uiControl["addUserForm"];
		?>                        <form class="form-horizontal"<?php
		echo Nette\Bridges\FormsLatte\Runtime::renderFormBegin(end($this->global->formsStack), array (
		'class' => NULL,
		), false) ?>>
                            <div class="form-group">
                                <div class="col-xs-5 col-sm-2 col-md-2 col-lg-2 F">* UserID</div>
                                <div class="col-xs-7 col-sm-10 col-md-10 col-lg-10">
                                    <input class="form-control" placeholder="User ID" id="uid"<?php
		$_input = end($this->global->formsStack)["uid"];
		echo $_input->getControlPart()->addAttributes(array (
		'class' => NULL,
		'placeholder' => NULL,
		'id' => NULL,
		))->attributes() ?>>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-5 col-sm-2 col-md-2 col-lg-2 F">* Password</div>
                                <div class="col-xs-7 col-sm-10 col-md-10 col-lg-10">
                                    <input class="form-control" placeholder="Password" id="pass1"<?php
		$_input = end($this->global->formsStack)["pass1"];
		echo $_input->getControlPart()->addAttributes(array (
		'class' => NULL,
		'placeholder' => NULL,
		'id' => NULL,
		))->attributes() ?>>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-5 col-sm-2 col-md-2 col-lg-2 F">* RePassword</div>
                                <div class="col-xs-7 col-sm-10 col-md-10 col-lg-10">
                                    <input class="form-control" placeholder="Password" id="pass2"<?php
		$_input = end($this->global->formsStack)["pass2"];
		echo $_input->getControlPart()->addAttributes(array (
		'class' => NULL,
		'placeholder' => NULL,
		'id' => NULL,
		))->attributes() ?>>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-5 col-sm-2 col-md-2 col-lg-2 F">* First Name</div>
                                <div class="col-xs-7 col-sm-10 col-md-10 col-lg-10">
                                    <input class="form-control" placeholder="First Name" id="fn"<?php
		$_input = end($this->global->formsStack)["fn"];
		echo $_input->getControlPart()->addAttributes(array (
		'class' => NULL,
		'placeholder' => NULL,
		'id' => NULL,
		))->attributes() ?>>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-5 col-sm-2 col-md-2 col-lg-2 F">* Last Name</div>
                                <div class="col-xs-7 col-sm-10 col-md-10 col-lg-10">
                                    <input class="form-control" placeholder="Last Name" id="ln"<?php
		$_input = end($this->global->formsStack)["ln"];
		echo $_input->getControlPart()->addAttributes(array (
		'class' => NULL,
		'placeholder' => NULL,
		'id' => NULL,
		))->attributes() ?>>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-5 col-sm-2 col-md-2 col-lg-2">Photo</div>
                                <div class="col-xs-7 col-sm-10 col-md-10 col-lg-10">
                                    <div class="input-group">
                                        <label class="input-group-btn">
                                            <span class="btn btn-primary">
                                                Browse&hellip; <input type="file" style="display: none;" id="Pic"<?php
		$_input = end($this->global->formsStack)["pic"];
		echo $_input->getControlPart()->addAttributes(array (
		'type' => NULL,
		'style' => NULL,
		'id' => NULL,
		))->attributes() ?>>
                                            </span>
                                        </label>
                                        <input type="text" class="form-control" readonly placeholder="jpg, gif, png"<?php
		$_input = end($this->global->formsStack)["pict"];
		echo $_input->getControlPart()->addAttributes(array (
		'type' => NULL,
		'class' => NULL,
		'readonly' => NULL,
		'placeholder' => NULL,
		))->attributes() ?>>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col col-xs-12">
                                    <button class="btn btn-default" value="true"<?php
		$_input = end($this->global->formsStack)["AddUser"];
		echo $_input->getControlPart()->addAttributes(array (
		'class' => NULL,
		'value' => NULL,
		))->attributes() ?>>
                                        <strong>Create User</strong>
                                    </button>
                                </div>
                            </div>
<?php
		echo Nette\Bridges\FormsLatte\Runtime::renderFormEnd(array_pop($this->global->formsStack), false);
?>                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
	}


	function blockFooter($_args)
	{
		extract($_args);
?>
    <script>
        function Scroll(){
            $('html, body').animate({
                scrollTop: $("#System_Message").offset().top
            }, 1000);
        }
        function Check() {
            if($('#uid').val() == ''){
                $('#Msg_Y').html('UID is null');
                $('#MsgDiv_Y').fadeIn('fast',function(){
                    Scroll();
                    $('#MsgDiv_Y').fadeOut(5000);
                    $('#uid').focus();
                });
                return false;
            }

            if($('#pass1').val() == ''){
                $('#Msg_Y').html('Password is null');
                $('#MsgDiv_Y').fadeIn('fast',function(){
                    Scroll();
                    $('#MsgDiv_Y').fadeOut(5000);
                    $('#pass1').focus();
                });
                return false;
            }

            if($('#pass2').val() == ''){
                $('#Msg_Y').html('RePassword is null');
                $('#MsgDiv_Y').fadeIn('fast',function(){
                    Scroll();
                    $('#MsgDiv_Y').fadeOut(5000);
                    $('#pass2').focus();
                });
                return false;
            }

            if($('#pass1').val() != $('#pass2').val()){
                $('#Msg_Y').html('Passwords mismatch');
                $('#MsgDiv_Y').fadeIn('fast',function(){
                    Scroll();
                    $('#MsgDiv_Y').fadeOut(5000);
                    $('#pass1').val('');
                    $('#pass2').val('');
                    $('#pass1').focus();
                });
                return false;
            }

            if($('#fn').val() == ''){
                $('#Msg_Y').html('First Name is null');
                $('#MsgDiv_Y').fadeIn('fast',function(){
                    Scroll();
                    $('#MsgDiv_Y').fadeOut(5000);
                    $('#fn').focus();
                });
                return false;
            }

            if($('#ln').val() == ''){
                $('#Msg_Y').html('Last Name is null');
                $('#MsgDiv_Y').fadeIn('fast',function(){
                    Scroll();
                    $('#MsgDiv_Y').fadeOut(5000);
                    $('#ln').focus();
                });
                return false;
            }

            return true;
        }
        $(function() {
            $(document).on('change', ':file',
                function() {
                    var input = $(this),
                        numFiles = input.get(0).files ? input.get(0).files.length : 1,
                        label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
                    input.trigger('fileselect', [numFiles, label]);
                });
        });
    $(document).ready( function() {
        $('#uid').focus();
        $('[id^=MsgDiv_]').fadeOut(5000);
        $(':file').on('fileselect', function(event, numFiles, label) {
            var input = $(this).parents('.input-group').find(':text'),
                log = numFiles > 1 ? numFiles + ' files selected' : label;
            if( input.length ) {
                input.val(log);
            } else {
                if( log ) alert(log);
            }
        });
    });
    </script>
<?php
	}

}
