<?php
// source: C:\xampp\htdocs\web-project\app\presenters\templates\users.latte

use Latte\Runtime as LR;

class Template5bf3fd6f5b extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		echo LR\Filters::escapeHtmlText($arr['data'][] = array('1','ali','imani','ss','act');
		$arr['data'][] = array('1','ali','imani','ss','act');
		$arr['data'][] = array('1','ali','imani','ss','act');
		echo json_encode($arr);
		) /* line 1 */;
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}

}
