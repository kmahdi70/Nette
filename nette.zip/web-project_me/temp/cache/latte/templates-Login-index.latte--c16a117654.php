<?php
// source: C:\xampp\htdocs\web-project\app\presenters/templates/Login/index.latte

use Latte\Runtime as LR;

class Templatec16a117654 extends Latte\Runtime\Template
{
	public $blocks = [
		'header' => 'blockHeader',
		'content' => 'blockContent',
		'footer' => 'blockFooter',
	];

	public $blockTypes = [
		'header' => 'html',
		'content' => 'html',
		'footer' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('header', get_defined_vars());
?>

<?php
		$this->renderBlock('content', get_defined_vars());
?>

<?php
		$this->renderBlock('footer', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	function blockHeader($_args)
	{
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>
<div style="margin-top: 10px">
<?php
		/* line 6 */
		$this->createTemplate('../message.latte', $this->params, "include")->renderToContentType('html');
?>
</div>
<div class="container">
    <div class="row" id="Login">
        <div class="col col-xs-6 col-xs-offset-3 col-sm-4 col-sm-offset-4">
            <div class="panel panel-default">
                <div class="panel-heading"><label class="control-label">User Login</label></div>
                <div class="panel-body">
                    <div class="col col-xs-12">
<?php
		$form = $_form = $this->global->formsStack[] = $this->global->uiControl["loginForm"];
		?>                        <form class="form-horizontal"<?php
		echo Nette\Bridges\FormsLatte\Runtime::renderFormBegin(end($this->global->formsStack), array (
		'class' => NULL,
		), false) ?>>
                            <div class="form-group">
                                <div class="col-xs-12">
                                    <input class="form-control" placeholder="User ID" id="uid"<?php
		$_input = end($this->global->formsStack)["uid"];
		echo $_input->getControlPart()->addAttributes(array (
		'class' => NULL,
		'placeholder' => NULL,
		'id' => NULL,
		))->attributes() ?>>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-12">
                                    <input class="form-control" placeholder="Password" id="pass"<?php
		$_input = end($this->global->formsStack)["pass"];
		echo $_input->getControlPart()->addAttributes(array (
		'class' => NULL,
		'placeholder' => NULL,
		'id' => NULL,
		))->attributes() ?>>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col col-xs-12">
                                    <button class="btn btn-default" value="true" onclick="return Check();"<?php
		$_input = end($this->global->formsStack)["Login"];
		echo $_input->getControlPart()->addAttributes(array (
		'class' => NULL,
		'value' => NULL,
		'onclick' => NULL,
		))->attributes() ?>>
                                        <strong>Login</strong>
                                    </button>
                                </div>
                            </div>
<?php
		echo Nette\Bridges\FormsLatte\Runtime::renderFormEnd(array_pop($this->global->formsStack), false);
?>                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
	}


	function blockFooter($_args)
	{
		extract($_args);
?>
<script>
    function Check() {
        if($('#uid').val() == ''){
            $('#Msg_Y').html('User ID is Null');
            $('#MsgDiv_Y').fadeIn('fast');
            $('#MsgDiv_Y').fadeOut(5000);
            $('#uid').focus();
            return false;
        }
        if($('#pass').val() == ''){
            $('#Msg_Y').html('Password is Null');
            $('#MsgDiv_Y').fadeIn('fast');
            $('#MsgDiv_Y').fadeOut(5000);
            $('#pass').focus();
            return false;
        }
        return true;
    }
    $(document).ready( function() {
        $('#uid').focus();
        $('[id^=MsgDiv_]').fadeOut(5000);
    });
</script>
<?php
	}

}
