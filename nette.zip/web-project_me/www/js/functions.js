$('#Panel_Title').click(function(){
    if($('#Panel_Body').css('display') != 'none') {
        $('#Panel_Body').slideUp('fast');
        $('#Panel_Icon').removeClass('fa-folder-open-o');
        $('#Panel_Icon').addClass('fa-folder-o');
    }
    else {
        $('#Panel_Body').slideDown('fast');
        $('#Panel_Icon').removeClass('fa-folder-o');
        $('#Panel_Icon').addClass('fa-folder-open-o');
    }
});
