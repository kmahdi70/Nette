<?php
/**
 * Created by PhpStorm.
 * User: Karimian
 * Date: 2017-09-23
 * Time: 6:50 PM
 */
namespace App\Model;

use Nette;

class User
{
    use Nette\SmartObject;

    private $database;

    public function __construct(Nette\Database\Context $database)
    {
        $this->database = $database;
    }

    public function getUser($uid=null, $pass=null)
    {
        return $this->database->fetch('SELECT * FROM users WHERE UID = ? AND Password = ?', $uid, sha1($pass));
    }

    public function AddUser($arr){

        $uid = $arr['uid'];
        $res = $this->database->query("select * from `users` where `UID`=?;", $uid);

        if($res->getRowCount() > 0)
            return -1;
        else{
            $this->database->query('INSERT INTO users', [
                'UID' => $uid,
                'Password' => $arr['pw'],
                'FN' => $arr['fn'],
                'LN' => $arr['ln'],
                'Pic' => $arr['pic']]);

            return $this->database->getInsertId();
        }

    }
    public function getUsers()
    {
        $Rows = $this->database->fetchAll('SELECT * FROM users');

        foreach($Rows as $K => $V){
            $arr['data'][] = array($V->UID,$V->FN,$V->LN,'<img src="data:image/jpeg;base64,'.base64_encode( $V->Pic).'" width="50">',$this->Button($V->UID));
        }
        return $arr;
    }

    public function Button($id){
        return ('<form method="post" style="float:left;margin-right:3px">
                    <input type="hidden" name="uid" value="'.$id.'">
                    <span data-toggle="tooltip" title="Edit" id="EditSpan">
                        <button type="submit" class="btn btn-primary btn-xs EditBt" title="Edit" data-target="#EditRow">    
                            <i class="fa fa-pencil" aria-hidden="true" style="font-size: 15px"></i>
                        </button>
                    </span>
                </form>
                <span data-toggle="tooltip" title="Delete" id="DeleteSpan" style="float: left">
                    <button type="button" class="btn btn-danger btn-xs" title="Delete" data-toggle="modal" data-target="#ConfirmDell" onclick="ConfirmDelete(\''.$id.'\',this);">    
                        <i class="fa fa-trash" aria-hidden="true" style="font-size: 15px"></i>
                    </button>
                </span>');
    }

    public function DelUser($uid){
        $result = $this->database->query('DELETE FROM users WHERE uid = ?', $uid);
        return $result->getRowCount();
    }
}