<?php
namespace App\Presenters;

use Nette;


class HomePresenter extends Nette\Application\UI\Presenter
{
    public function renderIndex()
    {
        include('error.php');
        $Section = $this->getSession('Section');
        if(! isset($Section->UID))
            $this->redirect("Login:index");
        $this->template->uid = $Section->UID;
        $this->template->Title = 'MainPage';

    }

}
