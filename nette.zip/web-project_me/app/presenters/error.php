<?php
define("ErrNum_100","Invalid Input");
define("ErrNum_101","No Database");
define("ErrNum_102","Invalid User Name or Password");
define("ErrNum_103","Logged in successfully");
define("ErrNum_104","Restricted Access to this page");
define("ErrNum_105","Table does not exist");
define("ErrNum_106","No Database Connection");
define("ErrNum_107","No Database found");
define("ErrNum_108","Query Failed");
define("ErrNum_109","Logged Out Successfully");
define("ErrNum_110","User created successfully");
define("ErrNum_111","User ID already exists");
define("ErrNum_112","User Deleted successfully");


$this->template->Msg = '';
$this->template->Col = 0;
$this->template->ShowDiv = array('0' => array('g' => 'none','r' => 'none','y' => 'none'));

if(isset($_GET['Msg'])) {
    $msg_arr = explode('_', $_GET['Msg']);

    $this->template->Col = strtolower($msg_arr[0]);

    $this->template->ShowDiv =
        array('g' => array('g' => 'block','r' => 'none','y' => 'none'),
            'r' => array('g' => 'none','r' => 'block','y' => 'none'),
            'y' => array('g' => 'none','r' => 'none','y' => 'block'));
    $this->template->Msg = eval("return(ErrNum_" . htmlentities($msg_arr[1]) . ");");
}