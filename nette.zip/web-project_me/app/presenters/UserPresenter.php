<?php
namespace App\Presenters;

use Nette;
use Nette\Application\UI\Form;
use App\Model\User;
use Nette\Utils;
use Nette\Forms;

class UserPresenter extends Nette\Application\UI\Presenter
{
    private $DB;
    public $FormSess;
    public function __construct(User $user)
    {
        $this->DB = $user;
    }

    public function renderAdd()
    {
        include('error.php');
        $Section = $this->getSession('Section');
        if(! isset($Section->UID))
            $this->redirect("Login:index");
        $this->template->uid = $Section->UID;
        $this->template->Title = 'Add User';
        $this->template->page= 'user';
    }

    protected function createComponentAddUserForm()
    {
        $form = new Form;
        $form->addText('uid')->setRequired('Please enter your User ID.');
        $form->addPassword('pass1')
            ->setRequired('Enter Password');
        $form->addPassword('pass2')
            ->setRequired('Retype Password')
            ->addRule(Form::EQUAL, 'Password mismatch', $form['pass1']);
        $form->addText('fn')->setRequired('Please enter your First Name.');
        $form->addText('ln')->setRequired('Please enter your Last Name.');
        $form->addUpload('pic', 'Thumbnail:')
            ->setRequired(false)
            ->addRule(Form::IMAGE, 'Thumbnail must be JPEG, PNG or GIF')
            ->addRule(Form::MAX_FILE_SIZE, 'Maximum file size is 100 kB.', 100 * 1024);
        $form->addText('pict');
        $form->addSubmit('AddUser');
        $form->onSuccess[] = [$this, 'AddUserSucceeded'];
        $this->FormSess = $this->getSession('Section');
        if(isset($this->FormSess->FormVals)){
            $form_arr = $this->FormSess->FormVals;
            $form->setDefaults($form_arr);
        }
        return $form;
    }

    public function AddUserSucceeded(Form $form, Nette\Utils\ArrayHash $values)
    {
        $arr = array('uid' => $values['uid'],
            'pw' => sha1($values['pass1']),
            'fn' => $values['fn'],
            'ln' => $values['ln'],
            'pic' => '');
        if($values['pict'] != ''){
            $file = $values['pic'];
            if ($file->isOk())
                $values['pic']->move('./upload/'.$values->pict);

            $fp = fopen('./upload/'.$values->pict,'r');
            $arr['pic'] = $fp;
        }
        $result = $this->DB->AddUser($arr);
        if($values['pict'] != '')
            fclose($fp);
        if($result == -1){
            $vals = $form->getValues();
            $this->FormSess = $this->getSession('Section');
            $this->FormSess->FormVals = $vals;
            $this->redirect('User:add?Msg=R_111');
        }
        else{
            $this->FormSess = $this->getSession('Section');
            unset($this->FormSess->FormVals);

            if($values['pict'] != '') {
                $part = pathinfo('./upload/' . $values->pict);
                $ext = $part['extension'];
                $filename = sha1($result);
                rename('./upload/' . $values->pict, './upload/' . $filename . '.' . $ext);
            }
            $this->redirect('User:add?Msg=G_110');
        }
    }

    public function renderView(){
        include('error.php');
        $Section = $this->getSession('Section');
        if(! isset($Section->UID))
            $this->redirect("Login:index");
        $this->template->uid = $Section->UID;
        $this->template->Title = 'View Users';
        $this->template->page= 'user';
    }
    public function actionFeedUser(){
        $arr = $this->DB->getUsers();
        $this->sendResponse(new \Nette\Application\Responses\JsonResponse($arr));
    }

    public function actionDelete(){
        $res = $this->DB->DelUser($_POST['UID']);
        $this->sendResponse(new \Nette\Application\Responses\JsonResponse($res));
    }
}