<?php
namespace App\Presenters;

use Nette;
use Nette\Application\UI\Form;
use App\Model\User;

class LoginPresenter extends Nette\Application\UI\Presenter
{
    private $DB;
    public $Session;

    public function __construct(User $user)
    {
        $this->DB = $user;
    }

    protected function createComponentLoginForm()
    {
        $form = new Form;
        $form->addText('uid')->setRequired('Please enter your User ID.');
        $form->addPassword('pass')->setRequired('Please enter your password.');
        $form->addSubmit('Login');
        $form->onSuccess[] = [$this, 'LoginFormSucceeded'];
        return $form;
    }

    public function LoginFormSucceeded(Form $form, Nette\Utils\ArrayHash $values)
    {
        $result = $this->DB->getUser($values->uid, $values->pass);
        if($result){
            $this->Session = $this->getSession('Section');
            $this->Session->UID = $result->UID;
            $this->Session->FN = $result->FN;
            $this->Session->LN = $result->LN;
            $this->redirect("Home:index?Msg=G_103");
        }
        else{
            $this->redirect("Login:index?Msg=R_102");
        }
    }

    public function renderIndex(){
        $this->template->Title = 'Login';
        include('error.php');
    }

    public function actionLogoff(){
        $this->Session = $this->getSession('Section');
        $this->Session->remove();
        $this->redirect("Login:index?Msg=G_109");
    }
}